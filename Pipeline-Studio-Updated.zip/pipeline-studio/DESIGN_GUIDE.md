# Editing the dashboard design

All application source remains C. Raylib styling is in `src/ui.c`; there is no CSS file.

## File responsibilities

- `src/main.c`: initialise the app, update the runner, call the UI, and shut down.
- `src/ui.h`: four public function declarations connecting main to the UI.
- `src/ui.c`: window size, colours, font, checkbox and scroll state, input handling, and drawing.
- `src/pipeline.c` and `src/pipeline.h`: unchanged compiler and test runner.

## Where to edit in ui.c

| Function or setting | Controls |
|---|---|
| WIDTH and HEIGHT | Window dimensions; the layout still uses fixed coordinates |
| BG, PANEL, TEXT, MUTED, MINT, ERROR_COLOR | Shared colours |
| label | Text drawing |
| box | Rounded rectangles |
| button | Button styling, hover and clicks |
| stage_card and stat_card | Reusable cards |
| logs | Output formatting and scrolling |
| draw_sidebar | Logo, sample buttons and sidebar labels |
| draw_header | Main title and introductory text |
| draw_summary | File count, completed runs and duration |
| draw_drop_zone | Drop area appearance and queued filenames |
| draw_run_controls | Execution checkbox, Run/Stop and Clear |
| draw_stages | Inspect, Build and Test card placement |
| draw_output | Output panel and status message |
| ui_handle_input | File-drop processing |
| ui_init and ui_shutdown | Window/font setup and cleanup |

`ui_draw` calls the drawing sections in order and owns BeginDrawing/EndDrawing. Do not add another pair around it in main. The UI's `execute` and `scroll` variables persist between frames. Pipeline state is passed by pointer so controls can start and stop runs.

Include `ui.h` from another source file, never `ui.c`. The Makefile compiles `ui.c` separately and links it into the same executable.

## Try an edit

Change MINT to `{170, 130, 255, 255}`, save, close the application, then run `make run` from the project directory. Edit the heading in `draw_header` for a second small change.

Moving a panel does not automatically move text or click regions that have separate coordinates. Update related coordinates together.

## Verification

The refactored application was compiled with C11 warnings enabled and the existing runner suite was run. The compiler/test runner source is unchanged. A fresh visual and mouse/drag-and-drop check is still needed on your desktop.

Moving functions between files improves organisation; it does not by itself improve runtime performance.
