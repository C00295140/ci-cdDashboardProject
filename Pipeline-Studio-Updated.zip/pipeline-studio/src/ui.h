#ifndef UI_H
#define UI_H

#include "pipeline.h"

/* Owns the raylib window and font. Call once before drawing. */
void ui_init(void);
/* Accepts dropped paths. Buttons are handled when ui_draw draws them. */
void ui_handle_input(Pipeline *pipeline);
/* Draws one complete frame, including BeginDrawing/EndDrawing. */
void ui_draw(Pipeline *pipeline);
/* Releases the font and closes the window. */
void ui_shutdown(void);

#endif
