#include "raylib.h"
#include "pipeline.h"
#include "ui.h"
#include <string.h>

/* Application lifecycle only; layout and styling live in ui.c. */
int main(int argc, char **argv) {
    bool capture = argc > 1 && !strcmp(argv[1], "--screenshot");
    int frames = 0;
    Pipeline pipeline;
    pipeline_init(&pipeline);
    ui_init();

    if (!capture) {
        for (int i = 1; i < argc; i++) pipeline_add(&pipeline, argv[i]);
    }

    while (!WindowShouldClose()) {
        pipeline_update(&pipeline);
        ui_handle_input(&pipeline);
        ui_draw(&pipeline);
        if (capture && ++frames == 3) {
            TakeScreenshot("../dashboard-preview.png");
            break;
        }
    }

    pipeline_dispose(&pipeline);
    ui_shutdown();
    return 0;
}
