# Pipeline Studio

A C11 and raylib desktop dashboard for building C files and optionally running them as test programs. This is a local build-and-test prototype, not a hosted CI or deployment service.

## Build on macOS

Install Apple command-line developer tools if needed (`xcode-select --install`). Open Terminal in this folder and run:

```sh
make setup
make run
```

`make setup` downloads and builds raylib 5.5 locally. It requires internet access. Compiled files and raylib dependencies are deliberately excluded from this source package.

The process runner also targets Linux, which needs the relevant raylib desktop development libraries. This version does not implement a Windows process runner.

## Try it

Choose Passing tests, enable Run trusted code as tests, then click Run pipeline. For your own project, clear the queue and drop its .c and .h files into the window. Include exactly one main function. Only execute code you trust: it runs with your user permissions.

The examples are separate programs: do not compile all three together. build_error.c deliberately contains a syntax error. A successful build does not guarantee correct behaviour; the test program must contain meaningful checks and return a nonzero exit code on failure.

## Test the runner

```sh
make test
```

## Files

- src/: C application and runner
- examples/: passing, failing, and compilation-error demonstrations
- tests/: runner tests
- Makefile: setup, build, run, and test commands
- STUDY_NOTES.md and QUICK_REVISION.md: explanations

## Add to GitHub

Extract this ZIP and add the project files to your repository. Uploading a ZIP alone stores an archive; it does not unpack the source into the repository. Include the hidden .gitignore file when committing with Git. Keep build/ and vendor/ out of the repository.
